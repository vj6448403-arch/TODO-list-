# JWT Authentication Full-Stack Project

A beginner-friendly JWT authentication project using Node.js, Express, bcryptjs, and a vanilla HTML/CSS/JavaScript frontend.

## Features
- User registration
- Password hashing with bcryptjs
- Login with JWT token
- Protected `/api/auth/me` route
- Protected `/api/protected` route
- Token stored in browser localStorage
- Logout
- CORS enabled

## Run backend
```bash
cd backend
cp .env.example .env
npm install
npm start
```
Backend runs at `http://localhost:5000`.

## Run frontend
Open `frontend/index.html` using VS Code Live Server, or serve the folder:
```bash
cd frontend
npx serve .
```

## API endpoints
- `GET /api/health`
- `POST /api/auth/register` body: `{ "name": "Vaishnavi", "email": "a@b.com", "password": "123456" }`
- `POST /api/auth/login` body: `{ "email": "a@b.com", "password": "123456" }`
- `GET /api/auth/me` header: `Authorization: Bearer <token>`
- `GET /api/protected` header: `Authorization: Bearer <token>`

## Important note
This demo stores users in memory, so users disappear when the backend restarts. For production, connect MongoDB/PostgreSQL, use secure HTTP-only cookies, rate limiting, validation, refresh tokens, and HTTPS.
