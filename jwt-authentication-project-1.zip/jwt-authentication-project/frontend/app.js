const API = 'http://localhost:5000/api';
let mode = 'login';
const $ = id => document.getElementById(id);
const token = () => localStorage.getItem('jwt');
function message(text, error=false){ $('message').textContent=text; $('message').style.color=error?'#dc2626':'#059669'; }
function setMode(next){ mode=next; $('loginTab').classList.toggle('active',mode==='login'); $('registerTab').classList.toggle('active',mode==='register'); $('nameGroup').classList.toggle('hidden',mode==='login'); $('submitBtn').textContent=mode==='login'?'Login':'Register'; $('authForm').reset(); message(''); }
$('loginTab').onclick=()=>setMode('login'); $('registerTab').onclick=()=>setMode('register');
$('authForm').onsubmit=async e=>{e.preventDefault(); const body={email:$('email').value,password:$('password').value}; if(mode==='register') body.name=$('name').value; try{const res=await fetch(`${API}/auth/${mode}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}); const data=await res.json(); if(!res.ok) throw new Error(data.message); localStorage.setItem('jwt',data.token); message(data.message); showDashboard(data.user);}catch(err){message(err.message,true)}};
async function showDashboard(user){$('authForm').classList.add('hidden');$('loginTab').classList.add('hidden');$('registerTab').classList.add('hidden');$('dashboard').classList.remove('hidden');$('userInfo').textContent=JSON.stringify(user,null,2)}
$('protectedBtn').onclick=async()=>{const res=await fetch(`${API}/protected`,{headers:{Authorization:`Bearer ${token()}`}});$('protectedResult').textContent=JSON.stringify(await res.json(),null,2)};
$('logoutBtn').onclick=()=>{localStorage.removeItem('jwt');location.reload()};
(async()=>{if(token()){const res=await fetch(`${API}/auth/me`,{headers:{Authorization:`Bearer ${token()}`}});if(res.ok){const data=await res.json();showDashboard(data.user)}}})();
