# Greenwood Library Website

Responsive editorial-style Greenwood Public Library landing page built with HTML and Tailwind CSS via CDN.

## Includes
- Sticky blurred responsive navbar and mobile menu
- Hero section with CTA buttons and feature image
- Statistics row
- Six interactive library section cards
- Responsive image gallery with hover zoom
- Asymmetric Bento-style values grid
- About text columns
- Membership cards with Popular badge
- Testimonial with grayscale-to-color avatar hover
- Contact CTA block
- Four-column events grid
- Multi-column footer and social icon circles

## Requirement
Native Tailwind CSS only. No external CSS framework and no custom fonts.

## Run
Open `index.html` in a modern browser. Internet is required for Tailwind CDN and remote images.
