To-Do List REST API Assignment

Contents:
- Todo_List_REST_API_Plan.docx: Complete API planning document.

The document covers Add, Read, Update, Patch/Complete, and Delete task APIs, including endpoints, HTTP methods, request bodies, expected responses, status codes, RESTful design, and error responses.
