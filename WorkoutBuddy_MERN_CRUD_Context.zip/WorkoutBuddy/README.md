# Workout Buddy — MERN CRUD + Context

Responsive MERN CRUD assignment with MongoDB, Express, React, Context API and useReducer.

## Run
### Backend
cd backend
npm install
cp .env.example .env
# Add your MongoDB Atlas URI to .env
npm run dev

### Frontend
cd frontend
npm install
npm run dev

Backend: http://localhost:5000
Frontend: Vite URL shown in terminal.
