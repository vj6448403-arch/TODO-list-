const express=require('express');const mongoose=require('mongoose');const cors=require('cors');require('dotenv').config();const routes=require('./routes/workouts');
const app=express();app.use(cors());app.use(express.json());app.get('/',(req,res)=>res.json({message:'Workout Buddy API is running'}));app.use('/api/workouts',routes);
app.use((err,req,res,next)=>res.status(err.status||500).json({error:err.message||'Something went wrong'}));
const PORT=process.env.PORT||5000;mongoose.connect(process.env.MONGO_URI).then(()=>{console.log('MongoDB connected');app.listen(PORT,()=>console.log(`Server running on port ${PORT}`));}).catch(e=>{console.error('MongoDB connection failed:',e.message);process.exit(1)});
