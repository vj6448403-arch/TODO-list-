# US Map Filter Exercise

## Files
- `index.html` - Complete HTML, CSS, and JavaScript solution.

## How to run
1. Extract the ZIP file.
2. Open `index.html` in any modern web browser.
3. Type a student's name in the search box.
4. The list updates automatically.

## JavaScript concepts used
- Array of student objects
- `filter()` to search students by name
- `map()` to create student cards dynamically
- DOM manipulation
- `input` event for real-time search
