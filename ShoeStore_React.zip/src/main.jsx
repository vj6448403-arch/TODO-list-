import React, { useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

const shoes = [
  {
    id: 1,
    name: "Air Runner",
    price: 2499,
    category: "Running",
    image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=700&q=80"
  },
  {
    id: 2,
    name: "Urban Classic",
    price: 2999,
    category: "Casual",
    image: "https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?auto=format&fit=crop&w=700&q=80"
  },
  {
    id: 3,
    name: "Street Flex",
    price: 2199,
    category: "Sneakers",
    image: "https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&w=700&q=80"
  },
  {
    id: 4,
    name: "Sport Max",
    price: 3299,
    category: "Sports",
    image: "https://images.unsplash.com/photo-1551107696-a4b0c5a0d9a2?auto=format&fit=crop&w=700&q=80"
  },
  {
    id: 5,
    name: "Daily Comfort",
    price: 1899,
    category: "Casual",
    image: "https://images.unsplash.com/photo-1495555961986-6d4c1ecb7be3?auto=format&fit=crop&w=700&q=80"
  },
  {
    id: 6,
    name: "Classic White",
    price: 2799,
    category: "Sneakers",
    image: "https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?auto=format&fit=crop&w=700&q=80"
  }
];

const money = (value) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0
  }).format(value);

function App() {
  const [cart, setCart] = useState([]);
  const [query, setQuery] = useState("");

  const addToCart = (shoe) => {
    setCart((current) => {
      const found = current.find((item) => item.id === shoe.id);
      if (found) {
        return current.map((item) =>
          item.id === shoe.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...current, { ...shoe, quantity: 1 }];
    });
  };

  const decreaseQuantity = (id) => {
    setCart((current) =>
      current
        .map((item) =>
          item.id === id ? { ...item, quantity: item.quantity - 1 } : item
        )
        .filter((item) => item.quantity > 0)
    );
  };

  const removeFromCart = (id) => {
    setCart((current) => current.filter((item) => item.id !== id));
  };

  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
  const totalPrice = cart.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  const filteredShoes = shoes.filter(
    (shoe) =>
      shoe.name.toLowerCase().includes(query.toLowerCase()) ||
      shoe.category.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="app">
      <header className="header">
        <div className="brand">
          <div className="brand-icon">👟</div>
          <div>
            <h1>SoleMate</h1>
            <span>SHOE STORE</span>
          </div>
        </div>

        <div className="search">
          <span>⌕</span>
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search shoes..."
            aria-label="Search shoes"
          />
        </div>

        <div className="cart-badge">
          <span className="cart-icon">🛒</span>
          <span>{totalItems} {totalItems === 1 ? "item" : "items"}</span>
        </div>
      </header>

      <main className="layout">
        <section className="products-section">
          <div className="section-heading">
            <div>
              <p className="eyebrow">EXPLORE OUR COLLECTION</p>
              <h2>Find your perfect pair</h2>
            </div>
            <span className="product-count">{filteredShoes.length} shoes</span>
          </div>

          <div className="products-grid">
            {filteredShoes.map((shoe) => (
              <article className="shoe-card" key={shoe.id}>
                <div className="image-wrap">
                  <img src={shoe.image} alt={shoe.name} />
                  <span className="category">{shoe.category}</span>
                </div>
                <div className="shoe-info">
                  <h3>{shoe.name}</h3>
                  <div className="rating">★★★★★ <small>4.8</small></div>
                  <div className="card-bottom">
                    <strong>{money(shoe.price)}</strong>
                    <button onClick={() => addToCart(shoe)}>Add to Cart</button>
                  </div>
                </div>
              </article>
            ))}
          </div>

          {filteredShoes.length === 0 && (
            <div className="empty-search">
              <div>🔎</div>
              <h3>No shoes found</h3>
              <p>Try another shoe name or category.</p>
            </div>
          )}
        </section>

        <aside className="cart-panel">
          <div className="cart-title">
            <div>
              <p className="eyebrow">YOUR SELECTION</p>
              <h2>Shopping Cart</h2>
            </div>
            <span className="cart-number">{totalItems}</span>
          </div>

          {cart.length === 0 ? (
            <div className="empty-cart">
              <div className="empty-cart-icon">🛍️</div>
              <h3>Your cart is empty</h3>
              <p>Add your favorite shoes to see them here.</p>
            </div>
          ) : (
            <>
              <div className="cart-items">
                {cart.map((item) => (
                  <div className="cart-item" key={item.id}>
                    <img src={item.image} alt={item.name} />
                    <div className="item-details">
                      <h3>{item.name}</h3>
                      <span>{money(item.price)} each</span>
                      <div className="quantity">
                        <button onClick={() => decreaseQuantity(item.id)}>-</button>
                        <b>{item.quantity}</b>
                        <button onClick={() => addToCart(item)}>+</button>
                      </div>
                    </div>
                    <div className="item-side">
                      <strong>{money(item.price * item.quantity)}</strong>
                      <button
                        className="remove"
                        onClick={() => removeFromCart(item.id)}
                        aria-label={`Remove ${item.name}`}
                      >
                        ×
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="summary">
                <div><span>Subtotal</span><strong>{money(totalPrice)}</strong></div>
                <div><span>Delivery</span><strong className="free">FREE</strong></div>
                <div className="total"><span>Total</span><strong>{money(totalPrice)}</strong></div>
                <button className="checkout" onClick={() => alert("Thank you for shopping with SoleMate!")}>
                  Proceed to Checkout →
                </button>
              </div>
            </>
          )}
        </aside>
      </main>

      <footer>
        <span>© 2026 SoleMate Shoe Store</span>
        <span>Built with React useState</span>
      </footer>
    </div>
  );
}

createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);