# SoleMate Shoe Store - React

A responsive online shoe store built with React and Vite.

## Features

- Displays a collection of shoes with name, category, price and image.
- Search shoes by name or category.
- Add shoes to the shopping cart.
- Increase or decrease quantity.
- Remove items from the cart.
- Calculates cart total automatically.
- Responsive design for desktop, tablet and mobile.
- Uses React `useState` for cart and search state.

## How to run

1. Install Node.js.
2. Open the project folder in VS Code/terminal.
3. Run:

```bash
npm install
npm run dev
```

4. Open the localhost address shown by Vite in your browser.

## Submission note

`node_modules` is intentionally not included. Run `npm install` after extracting the ZIP.
