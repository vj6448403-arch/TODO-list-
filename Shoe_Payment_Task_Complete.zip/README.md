# Shoe Store - Payment Task

This project implements the task shown in the provided screenshot:

- A shoe shopping website.
- Shopping cart with products, quantities and totals.
- A **Proceed to Payment** button on the cart.
- Clicking it redirects to a payment page.
- Payment page shows the cart summary and a credit-card payment form.
- Uses React **Context API** to manage cart data across pages.
- Uses browser `localStorage` so cart data survives refreshes.
- Includes basic card validation and a simulated successful payment flow.

## Run locally

```bash
npm install
npm run dev
```

Then open the local URL printed by Vite.

## Build

```bash
npm run build
npm run preview
```

> This is a frontend/demo payment implementation. It does not send or store real card details and does not connect to a real payment gateway.
