import { ShoppingCart } from "lucide-react";
import { useCart } from "../context/CartContext";

const money = (value) => `₹${value.toLocaleString("en-IN")}`;

export default function ProductCard({ product }) {
  const { addToCart } = useCart();

  return (
    <article className="product-card">
      <div className="product-image-wrap">
        <img src={product.image} alt={product.name} className="product-image" />
        <span className="category">{product.category}</span>
      </div>
      <div className="product-info">
        <h3>{product.name}</h3>
        <div className="product-bottom">
          <strong>{money(product.price)}</strong>
          <button className="add-btn" onClick={() => addToCart(product)}>
            <ShoppingCart size={17} /> Add
          </button>
        </div>
      </div>
    </article>
  );
}