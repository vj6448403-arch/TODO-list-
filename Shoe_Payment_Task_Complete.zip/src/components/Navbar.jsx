import { Link } from "react-router-dom";
import { ShoppingBag } from "lucide-react";
import { useCart } from "../context/CartContext";

export default function Navbar() {
  const { totalItems } = useCart();

  return (
    <header className="navbar">
      <Link to="/" className="brand">
        <span className="brand-mark">S</span>
        SoleMate
      </Link>

      <nav>
        <Link to="/">Home</Link>
        <Link to="/cart" className="cart-link">
          <ShoppingBag size={19} />
          Cart
          {totalItems > 0 && <span className="cart-badge">{totalItems}</span>}
        </Link>
      </nav>
    </header>
  );
}