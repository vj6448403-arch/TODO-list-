import { Link, useNavigate } from "react-router-dom";
import { Minus, Plus, Trash2, ArrowRight, ShoppingBag } from "lucide-react";
import { useCart } from "../context/CartContext";

const money = (value) => `₹${value.toLocaleString("en-IN")}`;

export default function Cart() {
  const { cart, updateQuantity, removeFromCart, subtotal } = useCart();
  const navigate = useNavigate();

  const shipping = subtotal > 0 && subtotal < 3000 ? 99 : 0;
  const total = subtotal + shipping;

  if (!cart.length) {
    return (
      <section className="empty-cart">
        <div className="empty-icon"><ShoppingBag size={40} /></div>
        <h1>Your cart is empty</h1>
        <p>Add a pair of shoes to continue to payment.</p>
        <Link to="/" className="primary-btn">Browse Shoes</Link>
      </section>
    );
  }

  return (
    <section className="cart-page">
      <div className="page-heading">
        <p className="eyebrow">SHOPPING CART</p>
        <h1>Your Cart</h1>
      </div>

      <div className="cart-layout">
        <div className="cart-items">
          {cart.map((item) => (
            <div className="cart-item" key={item.id}>
              <img src={item.image} alt={item.name} />
              <div className="cart-item-info">
                <p className="muted">{item.category}</p>
                <h3>{item.name}</h3>
                <strong>{money(item.price)}</strong>
              </div>

              <div className="quantity">
                <button onClick={() => updateQuantity(item.id, item.quantity - 1)}><Minus size={15} /></button>
                <span>{item.quantity}</span>
                <button onClick={() => updateQuantity(item.id, item.quantity + 1)}><Plus size={15} /></button>
              </div>

              <strong className="line-total">{money(item.price * item.quantity)}</strong>

              <button className="icon-btn danger" onClick={() => removeFromCart(item.id)} aria-label={`Remove ${item.name}`}>
                <Trash2 size={18} />
              </button>
            </div>
          ))}
        </div>

        <aside className="summary">
          <h2>Order Summary</h2>
          <div className="summary-row"><span>Subtotal</span><strong>{money(subtotal)}</strong></div>
          <div className="summary-row"><span>Shipping</span><strong>{shipping === 0 ? "FREE" : money(shipping)}</strong></div>
          <div className="divider" />
          <div className="summary-total"><span>Total</span><strong>{money(total)}</strong></div>

          <button className="payment-btn" onClick={() => navigate("/payment")}>
            Proceed to Payment <ArrowRight size={18} />
          </button>
          <Link to="/" className="continue-link">← Continue Shopping</Link>
        </aside>
      </div>
    </section>
  );
}