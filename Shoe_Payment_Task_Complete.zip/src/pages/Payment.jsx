import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { CreditCard, LockKeyhole, CheckCircle2 } from "lucide-react";
import { useCart } from "../context/CartContext";

const money = (value) => `₹${value.toLocaleString("en-IN")}`;

function formatCard(value) {
  return value.replace(/\D/g, "").slice(0, 16).replace(/(.{4})/g, "$1 ").trim();
}

function formatExpiry(value) {
  const digits = value.replace(/\D/g, "").slice(0, 4);
  return digits.length > 2 ? `${digits.slice(0, 2)}/${digits.slice(2)}` : digits;
}

export default function Payment() {
  const { cart, subtotal, clearCart } = useCart();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: "", card: "", expiry: "", cvv: "" });
  const [error, setError] = useState("");
  const [paid, setPaid] = useState(false);

  const shipping = subtotal > 0 && subtotal < 3000 ? 99 : 0;
  const total = subtotal + shipping;

  if (!cart.length && !paid) {
    return (
      <section className="empty-cart">
        <h1>No items to pay for</h1>
        <p>Your shopping cart is empty.</p>
        <Link to="/" className="primary-btn">Go to Store</Link>
      </section>
    );
  }

  const onChange = (e) => {
    const { name, value } = e.target;
    setForm((old) => ({
      ...old,
      [name]: name === "card" ? formatCard(value) : name === "expiry" ? formatExpiry(value) : name === "cvv" ? value.replace(/\D/g, "").slice(0, 3) : value
    }));
    setError("");
  };

  const submit = (e) => {
    e.preventDefault();
    const digits = form.card.replace(/\s/g, "");

    if (!form.name.trim()) return setError("Please enter the card holder name.");
    if (digits.length !== 16) return setError("Card number must contain 16 digits.");
    if (form.expiry.length !== 5) return setError("Enter expiry in MM/YY format.");
    if (form.cvv.length !== 3) return setError("CVV must contain 3 digits.");

    setPaid(true);
    clearCart();
  };

  if (paid) {
    return (
      <section className="success-page">
        <div className="success-icon"><CheckCircle2 size={58} /></div>
        <p className="eyebrow">PAYMENT COMPLETE</p>
        <h1>Order placed successfully!</h1>
        <p>Your demo payment was processed successfully. Thank you for shopping with SoleMate.</p>
        <Link to="/" className="primary-btn">Continue Shopping</Link>
      </section>
    );
  }

  return (
    <section className="payment-page">
      <div className="page-heading">
        <p className="eyebrow">SECURE CHECKOUT</p>
        <h1>Payment</h1>
      </div>

      <div className="payment-layout">
        <form className="payment-card" onSubmit={submit}>
          <div className="card-title">
            <div>
              <h2>Credit Card Payment</h2>
              <p>Enter your card details to complete the order.</p>
            </div>
            <CreditCard size={28} />
          </div>

          <label>
            Card Holder Name
            <input name="name" value={form.name} onChange={onChange} placeholder="e.g. Vaishnavi Jain" autoComplete="cc-name" />
          </label>

          <label>
            Card Number
            <input name="card" value={form.card} onChange={onChange} placeholder="1234 5678 9012 3456" inputMode="numeric" autoComplete="cc-number" />
          </label>

          <div className="form-row">
            <label>
              Expiry
              <input name="expiry" value={form.expiry} onChange={onChange} placeholder="MM/YY" inputMode="numeric" autoComplete="cc-exp" />
            </label>
            <label>
              CVV
              <input name="cvv" value={form.cvv} onChange={onChange} placeholder="123" inputMode="numeric" autoComplete="cc-csc" />
            </label>
          </div>

          {error && <p className="form-error">{error}</p>}

          <button className="payment-btn" type="submit">
            <LockKeyhole size={17} /> Pay {money(total)}
          </button>

          <p className="demo-note">Demo only — no real payment is submitted.</p>
        </form>

        <aside className="summary payment-summary">
          <h2>Order Summary</h2>
          {cart.map((item) => (
            <div className="mini-item" key={item.id}>
              <img src={item.image} alt={item.name} />
              <div>
                <strong>{item.name}</strong>
                <span>Qty: {item.quantity}</span>
              </div>
              <strong>{money(item.price * item.quantity)}</strong>
            </div>
          ))}
          <div className="divider" />
          <div className="summary-row"><span>Subtotal</span><strong>{money(subtotal)}</strong></div>
          <div className="summary-row"><span>Shipping</span><strong>{shipping ? money(shipping) : "FREE"}</strong></div>
          <div className="summary-total"><span>Total</span><strong>{money(total)}</strong></div>
          <button type="button" className="back-cart" onClick={() => navigate("/cart")}>← Back to Cart</button>
        </aside>
      </div>
    </section>
  );
}