import { Link } from "react-router-dom";
import ProductCard from "../components/ProductCard";
import { products } from "../data/products";

export default function Home() {
  return (
    <>
      <section className="hero">
        <div>
          <p className="eyebrow">NEW COLLECTION 2026</p>
          <h1>Step into your<br /><span>best look.</span></h1>
          <p className="hero-copy">
            Discover comfortable, modern shoes designed for every part of your day.
          </p>
          <Link to="/cart" className="primary-btn">View Shopping Cart</Link>
        </div>
        <div className="hero-shoe">
          <img src={products[0].image} alt="Featured running shoe" />
        </div>
      </section>

      <section className="products-section">
        <div className="section-heading">
          <div>
            <p className="eyebrow">OUR COLLECTION</p>
            <h2>Popular Shoes</h2>
          </div>
          <p>{products.length} products available</p>
        </div>
        <div className="product-grid">
          {products.map((product) => <ProductCard key={product.id} product={product} />)}
        </div>
      </section>
    </>
  );
}