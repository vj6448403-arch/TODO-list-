export const products = [
  {
    id: 1,
    name: "Air Runner",
    category: "Running",
    price: 2499,
    image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=80"
  },
  {
    id: 2,
    name: "Street Classic",
    category: "Casual",
    price: 1999,
    image: "https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?auto=format&fit=crop&w=900&q=80"
  },
  {
    id: 3,
    name: "Court Pro",
    category: "Sports",
    price: 2899,
    image: "https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&w=900&q=80"
  },
  {
    id: 4,
    name: "Urban White",
    category: "Lifestyle",
    price: 2299,
    image: "https://images.unsplash.com/photo-1495555961986-6d4c1ecb7be3?auto=format&fit=crop&w=900&q=80"
  },
  {
    id: 5,
    name: "Trail Max",
    category: "Outdoor",
    price: 3299,
    image: "https://images.unsplash.com/photo-1460353581641-37baddab0fa2?auto=format&fit=crop&w=900&q=80"
  },
  {
    id: 6,
    name: "Daily Flex",
    category: "Casual",
    price: 1799,
    image: "https://images.unsplash.com/photo-1560769629-975ec94e6a86?auto=format&fit=crop&w=900&q=80"
  }
];