import { Link, useNavigate } from 'react-router-dom';

export default function Signup() {
  const navigate = useNavigate();

  function handleSubmit(event) {
    event.preventDefault();
    navigate('/dashboard');
  }

  return (
    <section className="form-card page-card">
      <span className="pill">Signup</span>
      <h1>Create your account</h1>
      <p>Register to access the application dashboard.</p>
      <form onSubmit={handleSubmit}>
        <label>Full name<input type="text" placeholder="Your name" required /></label>
        <label>Email<input type="email" placeholder="you@example.com" required /></label>
        <label>Password<input type="password" placeholder="Create a password" minLength="6" required /></label>
        <button className="button primary" type="submit">Sign Up</button>
      </form>
      <p className="form-note">Already have an account? <Link to="/login">Login</Link></p>
    </section>
  );
}
