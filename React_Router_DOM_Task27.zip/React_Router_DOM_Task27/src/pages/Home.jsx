import { Link } from 'react-router-dom';

export default function Home() {
  return (
    <section className="hero page-card">
      <div className="hero-copy">
        <span className="pill">React Router DOM</span>
        <h1>Navigate your app without a page reload.</h1>
        <p>
          A simple multi-page experience built with React Router DOM.
          Explore the dashboard, login, and signup routes from one application.
        </p>
        <div className="actions">
          <Link className="button primary" to="/dashboard">Open Dashboard</Link>
          <Link className="button secondary" to="/signup">Create Account</Link>
        </div>
      </div>
      <div className="route-preview">
        <div className="preview-top"><span></span><span></span><span></span></div>
        <div className="preview-body">
          <div className="preview-sidebar">
            <div className="mini-logo">R</div>
            <div className="mini-line"></div><div className="mini-line"></div><div className="mini-line"></div>
          </div>
          <div className="preview-main">
            <div className="mini-title"></div>
            <div className="mini-cards"><div></div><div></div><div></div></div>
          </div>
        </div>
      </div>
    </section>
  );
}
