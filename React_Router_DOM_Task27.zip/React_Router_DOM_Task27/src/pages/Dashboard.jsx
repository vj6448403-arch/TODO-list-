import { Link } from 'react-router-dom';

const stats = [
  ['Active Routes', '04', 'Home, Dashboard, Login, Signup'],
  ['Navigation', '100%', 'Client-side routing'],
  ['Reloads', '0', 'Between application routes']
];

export default function Dashboard() {
  return (
    <section className="page-card">
      <div className="page-heading">
        <span className="pill">Dashboard</span>
        <h1>Application overview</h1>
        <p>Welcome to the dashboard route. This view is rendered by React Router DOM.</p>
      </div>
      <div className="stats-grid">
        {stats.map(([label, value, detail]) => (
          <article className="stat-card" key={label}>
            <p>{label}</p><strong>{value}</strong><span>{detail}</span>
          </article>
        ))}
      </div>
      <div className="info-box">
        <h2>Routing is working</h2>
        <p>Use the navigation bar to move between routes without leaving the React application.</p>
        <Link className="button primary" to="/">Back to Home</Link>
      </div>
    </section>
  );
}
