import { Link, useNavigate } from 'react-router-dom';

export default function Login() {
  const navigate = useNavigate();

  function handleSubmit(event) {
    event.preventDefault();
    navigate('/dashboard');
  }

  return (
    <section className="form-card page-card">
      <span className="pill">Login</span>
      <h1>Welcome back</h1>
      <p>Enter your details to continue to the dashboard.</p>
      <form onSubmit={handleSubmit}>
        <label>Email<input type="email" placeholder="you@example.com" required /></label>
        <label>Password<input type="password" placeholder="••••••••" required /></label>
        <button className="button primary" type="submit">Login</button>
      </form>
      <p className="form-note">New here? <Link to="/signup">Create an account</Link></p>
    </section>
  );
}
