import { Link } from 'react-router-dom';

export default function NotFound() {
  return (
    <section className="page-card not-found">
      <span className="error-code">404</span>
      <h1>Page not found</h1>
      <p>The route you requested does not exist.</p>
      <Link className="button primary" to="/">Return Home</Link>
    </section>
  );
}
