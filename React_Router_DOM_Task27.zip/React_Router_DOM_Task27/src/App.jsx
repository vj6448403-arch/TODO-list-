import { NavLink, Route, Routes } from 'react-router-dom';
import Home from './pages/Home';
import Dashboard from './pages/Dashboard';
import Login from './pages/Login';
import Signup from './pages/Signup';
import NotFound from './pages/NotFound';

function Navigation() {
  const links = [
    ['/', 'Home'],
    ['/dashboard', 'Dashboard'],
    ['/login', 'Login'],
    ['/signup', 'Signup']
  ];

  return (
    <header className="navbar">
      <NavLink to="/" className="brand">RouteSpace</NavLink>
      <nav className="nav-links" aria-label="Main navigation">
        {links.map(([to, label]) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}
          >
            {label}
          </NavLink>
        ))}
      </nav>
    </header>
  );
}

export default function App() {
  return (
    <div className="app-shell">
      <Navigation />
      <main className="main-content">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <footer className="footer">Task 27 · React Router DOM</footer>
    </div>
  );
}
