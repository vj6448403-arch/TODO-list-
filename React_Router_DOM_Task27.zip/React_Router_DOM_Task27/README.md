# Task 27: React Router DOM

## Problem statement
Implement navigation between different React routes using `react-router-dom`, allowing users to move between multiple views/pages of the application.

## Main routes
- `/` — Home
- `/dashboard` — Dashboard
- `/login` — Login
- `/signup` — Signup
- `*` — 404 Not Found fallback

## What is implemented
- `BrowserRouter` wraps the application.
- `Routes` and `Route` define the required routes.
- `NavLink` provides navigation with an active state.
- `Link` provides navigation buttons inside pages.
- `useNavigate` demonstrates programmatic navigation after the Login and Signup forms are submitted.
- A responsive layout and custom theme are included.
- A 404 route handles unknown URLs.
- No external image assets or UI frameworks are required.

## Run locally
1. Install Node.js.
2. Open this folder in a terminal.
3. Run `npm install`.
4. Run `npm run dev`.
5. Open the localhost URL shown by Vite.

## Test routes
Open these paths in the browser:
- `/`
- `/dashboard`
- `/login`
- `/signup`
- `/something-that-does-not-exist` to test the 404 page.

## Submission notes
`node_modules` is intentionally not included in the ZIP. Run `npm install` after extracting the project.
