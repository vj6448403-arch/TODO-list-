// Promise-based Divide Function
function divideNumbers(num1, num2) {
  return new Promise((resolve, reject) => {
    if (num2 === 0) {
      reject("Error: Cannot divide by zero.");
    } else {
      resolve(num1 / num2);
    }
  });
}

// Successful case
divideNumbers(20, 5)
  .then((result) => {
    console.log("Result:", result);
  })
  .catch((error) => {
    console.error(error);
  });

// Error case
divideNumbers(10, 0)
  .then((result) => {
    console.log("Result:", result);
  })
  .catch((error) => {
    console.error(error);
  });
