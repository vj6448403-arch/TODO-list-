# JavaScript - Promise-based Divide Function

## Objective
Create a JavaScript function that uses a Promise to perform division.

## Requirements
- Accept two numbers.
- Return a Promise.
- Resolve with the division result when the divisor is not zero.
- Reject with an error when the divisor is zero.
- Handle success with `.then()`.
- Handle errors with `.catch()`.

## How to Run
1. Open `index.html` in a browser.
2. Open Developer Tools (F12).
3. Go to the Console tab.
4. You should see:

```text
Result: 4
Error: Cannot divide by zero.
```
